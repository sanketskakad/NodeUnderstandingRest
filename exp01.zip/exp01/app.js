const express = require("express");
const path = require("path");
const mongoose = require("mongoose")
const bodyparser = require("body-parser")
let Gage = 0
const Person = require("./schema/schema")
//const Person = mongoose.model("Person", {firstname: String, Lastname: String} );





mongoose.connect("mongodb://localhost:27017/mydb", { useNewUrlParser: true });

const db = mongoose.connection;

const app = express();

app.use(bodyparser.json());

app.use(express.urlencoded({ extended: false }))

db.on("error", () => {
    console.log("error")
})

db.on("open", () => {
    app.listen(3000, () => {
        console.log("App is running on port 3000");
    });
})

app.set("views", path.join(__dirname, "views"))
app.set("view engine", "ejs")

app.use(express.static("public"))



app.get("/api/:a/:b", (req, res) => {
    res.render("add", { a: req.params.a, b: req.params.b })
})

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "index.html"));
})

app.post("/submit", (req, res) => {
    Gage++
    let addperson = new Person({
        firstname: Gage + '_' + req.body.firstname,
        Lastname: Gage + '_' + req.body.lastname,
        age: Gage
    })
    addperson.save().then((data) => {
        res.redirect("/")
    })
})

app.get("/persons", (req, res) => {
    Person.find({}, (err, docs) => {
        res.send(docs);
    })
})

app.get("/error", (req, res) => {
    throw new Error("Unknown");  
})

app.delete("/persons", (req, res) => {
    Person.deleteMany({}, (err, docs) => {
        console.log("Delete All")
        res.send(docs);
    })
})

app.get("/persons/:id", (req, res) => {
    Person.find({ _id: req.params.id }, (err, docs) => {
        res.send(docs);
    })
})

app.delete("/persons/:id", (req, res) => {
    Person.remove({ _id: req.params.id }, (err, docs) => {
        res.send(docs);
    })
})




process.on("uncaughtException", (err) => {
    console.log("uncaughtException")
    console.log(err)

})



