const mongoose = require("mongoose")

const schema = mongoose.Schema;

let person = new schema({
    firstname:{
        type:String    
    },
    Lastname: {
        type:String    
    },
    Age: {
        type:Number    
    }
    
})

module.exports = mongoose.model("person", person );
